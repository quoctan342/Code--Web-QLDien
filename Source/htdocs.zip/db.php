<?php
    $conn = mysqli_connect('localhost', 'root', '', 'db_electric') or die ('Lỗi kết nối'); 
    mysqli_set_charset($conn, "utf8");
?>